#ifndef LIVRO_H
#define LIVRO_H

#include <string>
#include "Autor.h"

using namespace std;

class Livro
{
private:
    string _titulo;
    int _paginas;
    string _idioma;
    string _nome_autor;
    Autor *_autor;
public:
    Livro(Autor*);
    Livro(string titulo, int paginas, string idioma, Autor* autor);
    ~Livro(){}

    void set_titulo(string a){_titulo = a;}
    void set_paginas(int a){_paginas = a;}
    void set_idioma(string a){_idioma = a;}
    void set_autor(Autor* a){_autor = a;}

    string get_titulo(){return _titulo;}
    int get_paginas(){return _paginas;}
    string get_idioma(){return _idioma;}
    string get_nome_autor(){return _nome_autor;}
    Autor* get_autor(){return _autor;}

    void cadastrar_livro();
    void editar_livro();
    void excluir_livro();
    void exibir_livro();
};


#endif