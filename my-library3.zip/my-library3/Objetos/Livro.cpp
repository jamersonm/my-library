#include <iostream>
#include <string>
#include <ios> //for <streamsize>
#include <limits> //for numeric_limits
#include "Livro.h"
#include "Autor.h"

using namespace std;

Livro::Livro(Autor* autor)
{
    _autor = autor;
    _nome_autor = autor->get_nome_autor();
    cadastrar_livro();
}

Livro::Livro(string titulo, int paginas, string idioma, Autor* autor)
{
    _titulo = titulo;
    _paginas = paginas;
    _idioma = idioma;
    _autor = autor;
    _nome_autor = autor->get_nome_autor();
}

void Livro::cadastrar_livro()
{
    cout << "Autor: " << _nome_autor << endl;
    cout << "Título: ";
    getline(cin, _titulo);
    cout << "Páginas: ";
    cin >> _paginas;
    cin.ignore(numeric_limits<streamsize>::max(),'\n');
    cout << "Idioma: ";
    getline(cin, _idioma);
}

void Livro::editar_livro()
{
    cadastrar_livro();
}

void Livro::excluir_livro()
{
    Livro::~Livro();
}

void Livro::exibir_livro()
{
    cout << "Título: " << _titulo << endl;
    cout << "Autor: " << _nome_autor << endl;
    cout << "Paginas: " << _paginas << endl;
    cout << "Idioma: " << _paginas << endl;
}