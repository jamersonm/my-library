#include "Biblioteca/Biblioteca.h"

int main()
{
    Biblioteca b;
    return 0;
}