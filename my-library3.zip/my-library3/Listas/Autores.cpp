#include <iostream>
#include "Autores.h"

using namespace std;

void Autores::criar_autor()
{
    Autor a;
    autores.push_back(a);
}

void Autores::criar_autor(string nome, string genero, string nacionalidade)
{
    Autor a(nome, genero, nacionalidade);
    autores.push_back(a);
}

Autor* Autores::pesquisar_autor(string nome)
{
    for(it = autores.begin(); it != autores.end(); ++it)
    {
        if((*it).get_nome_autor() == nome)
        {
            return &(*it);
        }
    }
    cout << "Autor não localizado" << endl;
    return;
}

Autor* Autores::get_autor(int index)
{
    it = autores.begin();
    advance(it, index - 1);
    return &(*it);
}

void Autores::exibir_lista_autores()
{
    _index_autores = 1;
    for(it = autores.begin(); it != autores.end(); ++it)
    {
        cout << _index_autores << ". " << (*it).get_nome_autor() << endl;
        _index_autores++;
    }
}