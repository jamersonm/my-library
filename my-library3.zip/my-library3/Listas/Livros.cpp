#include <iostream>
#include <ios> //for <streamsize>
#include <limits> //for numeric_limits
#include "Livros.h"

using namespace std;

void Livros::criar_livro(Autores lista_autores)
{
    lista_autores.exibir_lista_autores();
    cout << lista_autores.get_tamanho_lista_autores() + 1 << ". Voltar" << endl;
    int resp;

    do
    {
        cin >> resp;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if(resp == lista_autores.get_tamanho_lista_autores() + 1)
            return;
    } while (resp <= 0 || resp >= lista_autores.get_tamanho_lista_autores() + 2);
    
    Livro l(lista_autores.get_autor(resp));
    livros.push_back(l);
}

void Livros::criar_livro(string titulo, int paginas, string idioma, string nome_autor, Autores lista_autores)
{
    Livro l(titulo, paginas, idioma, lista_autores.pesquisar_autor(nome_autor));
    livros.push_back(l);
}

Livro* Livros::pesquisar_livro(string titulo)
{
    for(it = livros.begin(); it != livros.end(); ++it)
    {
        if((*it).get_titulo() == titulo)
        {
            return &(*it); 
        }    
    }
    cout << "Livro não localizado" << endl;
    return;    
}

Livro* Livros::get_livro(int index)
{
    it = livros.begin();
    advance(it, index);
    return &(*it);
}

void Livros::exibir_lista_livros()
{
    _index_livros = 1;
    for(it = livros.begin(); it != livros.end(); ++it)
    {
        cout << _index_livros << ". " << (*it).get_titulo() << endl;
        _index_livros++;   
    }
}