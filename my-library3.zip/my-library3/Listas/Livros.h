#ifndef LIVROS_H
#define LIVROS_H

#include <list>
#include "../Objetos/Livro.h"
#include "Autores.h"

class Livros
{
private:
    list<Livro> livros;
    list<Livro>::iterator it;
    int _index_livros;
public:
    Livros(){}
    ~Livros(){}

    int get_tamanho_lista_livros(){return livros.size();}
    list<Livro>::iterator get_it_begin(){return livros.begin();}
    list<Livro>::iterator get_it_end(){return livros.end();}

    void criar_livro(Autores lista_autores);
    void criar_livro(string titulo, int paginas, string idioma, string nome_autor, Autores lista_autores);

    Livro* pesquisar_livro(string);
    Livro* get_livro(int);

    void exibir_lista_livros();
};

#endif