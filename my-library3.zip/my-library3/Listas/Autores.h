#ifndef AUTORES_H
#define AUTORES_H

#include <list>
#include "../Objetos/Autor.h"

class Autores
{
private:
    list<Autor> autores;
    list<Autor>::iterator it;
    int _index_autores; //exibir
public:
    Autores(){}
    ~Autores(){}

    int get_tamanho_lista_autores(){return autores.size();}

    void criar_autor();
    void criar_autor(string, string, string);

    Autor* pesquisar_autor(string);
    Autor* get_autor(int);

    void exibir_lista_autores();
};

#endif