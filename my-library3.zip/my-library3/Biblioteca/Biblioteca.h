#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

#include <list>
#include "../Listas/Autores.h"
#include "../Listas/Livros.h"
#include "Registrador.h"
#include "Organizador.h"

class Biblioteca
{
private:
    Livros livros;
    Autores autores;
public:
    Biblioteca();
    ~Biblioteca();

    Livros get_lista_livros(){return livros;}
    Autores get_lista_autores(){return autores;}

    void menu_principal();
    void menu_autores();
    void menu_livros();
    void menu_ordem();
};

#endif