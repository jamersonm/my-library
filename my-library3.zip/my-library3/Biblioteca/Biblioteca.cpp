#include <iostream>
#include <ios> //for <streamsize>
#include <limits> //for numeric_limits
#include "Biblioteca.h"

using namespace std;

Biblioteca::Biblioteca()
{
    criar_csv();
    ler_csv_input(&livros, &autores);
    menu_principal();
}

Biblioteca::~Biblioteca()
{
    limpar_csv();
    escrever_csv(&livros, &autores);
    //exit(0);
}

void Biblioteca::menu_principal()
{
    int resp;
    cout << "------- MENU PRINCIPAL -------" << endl << endl;
    cout << "1. Autores" << endl;
    cout << "2. Livros" << endl;
    cout << "3. Organização e ordenação" << endl;
    cout << "4. Sair" << endl;
    while (resp <= 0 || resp > 4)
    {
        cin >> resp;
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        if (resp <= 0 || resp > 4)
            cout << "Opção inválida" << endl;
    }
    switch (resp)
    {
    case 1:
        menu_autores();
        break;
    case 2:
        menu_livros();
        break;
    case 3:
        menu_ordem();
        break;
    default:
        Biblioteca::~Biblioteca();
        break;
    }
}

void Biblioteca::menu_autores()
{
    cout << "------- MENU AUTORES -------" << endl << endl;
    int resp;
    cout << "1. Adicionar" << endl;
    cout << "2. Exibir" << endl;
    cout << "3. Listar" << endl;
    cout << "4. Editar" << endl;
    cout << "5. Excluir" << endl;
    cout << "6. Voltar" << endl;
    while (resp <= 0 || resp > 6)
    {
        cin >> resp;
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        if (resp <= 0 || resp > 6)
            cout << "Opção inválida" << endl;
    }
    string nome;
    switch (resp)
    {
    case 1:
        autores.criar_autor();
        break;
    case 2:
        cout << "Digite o nome do autor que deseja exibir: ";
        getline(cin, nome);
        autores.pesquisar_autor(nome)->exibir_autor();
        break;
    case 3:
        autores.exibir_lista_autores(); 
        break; 
    case 4:
        cout << "Digite o nome do autor que deseja editar: ";
        getline(cin, nome);
        autores.pesquisar_autor(nome)->editar_autor();
        break;    
    case 5:
        cout << "Digite o nome do autor que deseja excluir: ";
        getline(cin, nome);
        autores.pesquisar_autor(nome)->~Autor();
        break;
    default:
        menu_principal();
        break;
    }
    menu_autores();
}

void Biblioteca::menu_livros()
{
    cout << "------- MENU LIVROS -------" << endl << endl;
    int resp;
    cout << "1. Adicionar" << endl;
    cout << "2. Exibir" << endl;
    cout << "3. Listar" << endl;
    cout << "4. Editar" << endl;
    cout << "5. Excluir" << endl;
    cout << "6. Voltar" << endl; 
    while (resp <= 0 || resp > 6)
    {
        cin >> resp;
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        if (resp <= 0 || resp > 6)
            cout << "Opção inválida" << endl;
    }
    string titulo;
    switch (resp)
    {
    case 1:
        livros.criar_livro(&autores);
        break;
    case 2:
        cout << "Digite o titulo do livro que deseja exibir: ";
        getline(cin, titulo);
        livros.pesquisar_livro(titulo)->exibir_livro();
        break;
    case 3:
        livros.exibir_lista_livros();
        break;
    case 4:
        cout << "Digite o titulo do livro que deseja editar: ";
        getline(cin, titulo);
        livros.pesquisar_livro(titulo)->editar_livro();    
        break; 
    case 5:
        cout << "Digite o titulo do livro que deseja exluir: ";
        getline(cin, titulo);
        livros.pesquisar_livro(titulo)->excluir_livro();
        break;
    default:
        menu_principal();
        break;
    }
    menu_livros();
}

void Biblioteca::menu_ordem()
{
    cout << "------- MENU ORGANIZAÇÃO -------" << endl << endl;
    int resp;
    cout << "1. Ordem decrescente de páginas" << endl;
    cout << "2. Ordem crescente de páginas" << endl;
    cout << "3. Ordem alfabética dos títulos" << endl;
    cout << "4. Ordem alfabética dos autores" << endl;
    cout << "5. Organização por idiomas" << endl;
    cout << "6. Organização por países" << endl;
    cout << "7. Organização por generos" << endl;
    cout << "8. Voltar" << endl; 
    while (resp <= 0 || resp > 8)
    {
        cin >> resp;
        cin.ignore(numeric_limits<streamsize>::max(),'\n');
        if (resp <= 0 || resp > 8)
            cout << "Opção inválida" << endl;
    }
    string titulo;
    switch (resp)
    {
    case 1:
        ordem_numerica("decrescente", &livros);
        break;
    case 2:
        ordem_numerica("crescente", &livros);
        break;
    case 3:
        break;
    case 4:  
        break; 
    case 5:
        break;
    case 6:
        break;
    case 7:
        break;
    default:
        menu_principal();
        break;
    }
    menu_ordem();  
}