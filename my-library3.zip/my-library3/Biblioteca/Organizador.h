#include <iostream>
#include <list>
#include <iterator>
#include "Biblioteca.h"

using namespace std;

void ordem_numerica(string ordem, Livros* livros)
{
    list<Livro>::iterator it, itp, itpp;
    it = livros->get_it_begin();
    itp = it++;
    itpp = itp++;
    if(ordem == "crescente")
    {
        for(int i = 0; i < livros->get_tamanho_lista_livros(); i++)
        {
            if((*it).get_paginas() > (*it).get_paginas())
                swap(*itp, *itpp);
            else
                swap(*itp, *it);
        }
        if(++itp == livros->get_it_end())
            return;
        itpp++;
        itp++;
        it++;
    }
    else
    {
        for(int i = 0; i < livros->get_tamanho_lista_livros(); i++)
        {
            if((*it).get_paginas() < (*it).get_paginas())
                swap(*itp, *itpp);
            else
                swap(*itp, *it);
        }
        if(++itp == livros->get_it_end())
            return;
        itpp++;
        itp++;
        it++;
    }
}

/*void ordem_alfabetica(string dado, Livros* livros)
{
    if(dado == "titulos")
    {

    }
    else if(dado == "autores")
    {

    }
    else if(dado == "idioma")
    {

    }
    else if(dado == "pais")
    {

    }
    else
    {
        
    }
}*/