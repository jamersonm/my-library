#include <iostream>
#include <string>
#include <list>
#include <iterator>
#include <fstream>
#include <sstream>
#include <vector>

#include "Livros.h"
#include "Autores.h"
#include "Biblioteca.h"

using namespace std;

int main()
{
    Biblioteca b;
    b.interface_principal();
    return 0;
}