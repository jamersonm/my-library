#ifndef ORDENIZADOR_H
#define ORDENIZADOR_H

#include <iostream>
#include <list>
#include <iterator>
#include "Livros.h"

using namespace std;

void ordem_numerica(Livros *l, string a)
{
    
    if (a == "decrescente")
    {
        list<Livro>::iterator it, itp, itpp;
        it = l->get_begin();
        itp = it++;
        itpp = itp++;
        for(int i = 0; i < l->get_tam_livros(); i++)
        {
            if ((*it).get_paginas() > (*itp).get_paginas())
            {
                swap(*itp, *itpp);
            }
            else
            {
                swap(*itp, *it);
            }
            if(++itpp == l->get_end())
                break;
            itpp++;
            itp++;
            it++;
        }
    }
    else //crescente
    {

    }
}

#endif